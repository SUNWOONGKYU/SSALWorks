const fs = require('fs');
const path = require('path');

const templatesPath = path.join(__dirname, 'ordersheet_templates.json');
const templates = JSON.parse(fs.readFileSync(templatesPath, 'utf8'));

// 템플릿 생성 함수
function createTemplate(name, parent = null) {
  const displayName = parent ? `${parent} - ${name}` : name;

  return `# Order Sheet: ${displayName}

## 📋 작업 목적
${getWorkPurpose(name, parent)}

## 🎯 작업 범위
${getWorkScope(name, parent)}

## 📌 주요 고려사항
${getConsiderations(name, parent)}

## 📂 산출물
${getDeliverables(name, parent)}

## 💬 특이사항
여기에 추가 요구사항을 작성하세요.
`;
}

// 작업 목적 생성
function getWorkPurpose(name, parent) {
  const purposes = {
    // Phase 1: 기획
    '디렉토리 구조': '프로젝트 전체 디렉토리 구조 설계 및 문서화',
    'requirements': '프로젝트 기능 요구사항 정의 및 명세',
    'user_flows': '사용자 플로우 설계 및 시각화',
    'workflows': '비즈니스 워크플로우 설계 및 문서화',
    '디자인 가이드라인': 'UI/UX 디자인 가이드라인 및 스타일 가이드 수립',
    '목업': 'UI 목업 및 화면 설계',
    '프로토타입': '인터랙티브 프로토타입 제작',
    '데이터베이스 설계': '데이터베이스 스키마 및 ERD 설계',

    // Phase 2: 개발준비
    'Docker': 'Docker 컨테이너 환경 설정',
    'Environment': '개발 환경 변수 및 설정 파일 구성',
    'Git': 'Git 저장소 설정 및 브랜치 전략 수립',
    'Node': 'Node.js 환경 설정 및 패키지 관리',
    'Supabase': 'Supabase 프로젝트 설정 및 연동',
    'Vercel': 'Vercel 배포 환경 설정',
    'manual': '프로젝트 그리드 매뉴얼 작성',
    'project_grid': '프로젝트 그리드 구조 설계',
    'scripts': '프로젝트 그리드 자동화 스크립트',
    'tasks': '프로젝트 그리드 작업 관리',
    'validation': '프로젝트 그리드 검증 시스템',

    // Phase 3: 개발 - 프론트엔드
    'css': 'CSS 스타일시트 작성 및 관리',
    'js': 'JavaScript 로직 구현',
    'pages': 'HTML 페이지 구현',
    'public': '정적 리소스 관리',

    // Phase 3: 개발 - 인증
    'Email_Auth': '이메일 기반 인증 시스템 구현',
    'Google_OAuth': 'Google OAuth 2.0 인증 연동',
    'Session_Management': '세션 관리 및 인증 상태 유지',

    // Phase 3: 개발 - 백엔드
    '백엔드 인프라': '백엔드 서버 인프라 구축',

    // Phase 3: 개발 - 데이터베이스
    'scripts': '데이터베이스 마이그레이션 및 시드 스크립트',

    // Phase 3: 개발 - 외부 서비스
    'Email': '이메일 발송 서비스 연동',
    'Payments': '결제 시스템 연동',

    // Phase 3: 개발 - 테스트
    '1_api': 'API 테스트 작성 및 실행',
    '2_auth': '인증 시스템 테스트',
    '3_e2e': 'E2E(End-to-End) 테스트 구현',
    '4_integration': '통합 테스트 작성',
    '5_unit': '단위 테스트 작성',

    // Phase 3: 개발 - 배포
    '.github': 'GitHub Actions 워크플로우 설정',
    'CI_CD': 'CI/CD 파이프라인 구축',
    'Environment_Variables': '배포 환경 변수 관리',
    'Production_Config': '프로덕션 환경 설정',
    'Vercel_Deploy': 'Vercel 배포 자동화',

    // Phase 3: 개발 - 안정화
    'Hotfix': '긴급 버그 수정 및 배포',
    'Patch': '패치 버전 업데이트',
    'Performance_Tuning': '성능 최적화 및 튜닝',
    'Troubleshooting': '문제 해결 및 디버깅'
  };

  return purposes[name] || `${name} 작업 수행`;
}

// 작업 범위 생성
function getWorkScope(name, parent) {
  const scopes = {
    // Phase 1: 기획
    '디렉토리 구조': '- [ ] 프로젝트 디렉토리 구조 설계\n- [ ] 폴더별 용도 정의\n- [ ] 네이밍 규칙 수립\n- [ ] 디렉토리 구조 문서화',
    'requirements': '- [ ] 기능 요구사항 정의\n- [ ] 비기능 요구사항 정의\n- [ ] 사용자 스토리 작성\n- [ ] 우선순위 설정',
    'user_flows': '- [ ] 주요 사용자 플로우 설계\n- [ ] 플로우 다이어그램 작성\n- [ ] 예외 상황 플로우 정의\n- [ ] 플로우 검증',
    'workflows': '- [ ] 비즈니스 프로세스 분석\n- [ ] 워크플로우 다이어그램 작성\n- [ ] 자동화 가능 영역 식별\n- [ ] 워크플로우 문서화',
    '디자인 가이드라인': '- [ ] 컬러 팔레트 정의\n- [ ] 타이포그래피 설정\n- [ ] 컴포넌트 스타일 가이드\n- [ ] 아이콘 및 이미지 가이드라인',
    '목업': '- [ ] 와이어프레임 작성\n- [ ] 목업 디자인\n- [ ] 반응형 디자인 고려\n- [ ] 디자인 리뷰',
    '프로토타입': '- [ ] 인터랙티브 프로토타입 제작\n- [ ] 사용자 테스트\n- [ ] 피드백 수집 및 반영\n- [ ] 최종 프로토타입 검증',
    '데이터베이스 설계': '- [ ] 엔티티 정의\n- [ ] ERD 작성\n- [ ] 테이블 스키마 설계\n- [ ] 인덱스 및 제약조건 정의',

    // Phase 2: 개발준비
    'Docker': '- [ ] Dockerfile 작성\n- [ ] docker-compose.yml 설정\n- [ ] 컨테이너 이미지 빌드\n- [ ] 로컬 환경 테스트',
    'Environment': '- [ ] .env 파일 구조 설계\n- [ ] 환경별 설정 분리\n- [ ] 환경 변수 문서화\n- [ ] 시크릿 관리 방안 수립',
    'Git': '- [ ] Git 저장소 초기화\n- [ ] .gitignore 설정\n- [ ] 브랜치 전략 수립\n- [ ] 커밋 컨벤션 정의',
    'Node': '- [ ] Node.js 버전 설정\n- [ ] package.json 구성\n- [ ] 의존성 패키지 설치\n- [ ] 스크립트 명령어 정의',
    'Supabase': '- [ ] Supabase 프로젝트 생성\n- [ ] API 키 설정\n- [ ] 데이터베이스 연결\n- [ ] 연동 테스트',
    'Vercel': '- [ ] Vercel 프로젝트 연결\n- [ ] 배포 설정\n- [ ] 환경 변수 등록\n- [ ] 도메인 설정',
    'manual': '- [ ] 프로젝트 그리드 개념 문서화\n- [ ] 사용 방법 가이드 작성\n- [ ] 예제 포함\n- [ ] FAQ 작성',
    'project_grid': '- [ ] 그리드 구조 설계\n- [ ] Phase 정의\n- [ ] Task 템플릿 작성\n- [ ] 그리드 초기화',
    'scripts': '- [ ] 자동화 스크립트 작성\n- [ ] 그리드 생성 스크립트\n- [ ] 검증 스크립트\n- [ ] 유틸리티 함수',
    'tasks': '- [ ] Task 정의\n- [ ] 우선순위 설정\n- [ ] 의존성 관리\n- [ ] 진행 상황 추적',
    'validation': '- [ ] 검증 규칙 정의\n- [ ] 자동 검증 스크립트\n- [ ] 검증 리포트 생성\n- [ ] 검증 결과 처리',

    // Phase 3: 개발 - 프론트엔드
    'css': '- [ ] 글로벌 스타일 정의\n- [ ] 컴포넌트별 스타일 작성\n- [ ] 반응형 CSS\n- [ ] CSS 최적화',
    'js': '- [ ] 비즈니스 로직 구현\n- [ ] 이벤트 핸들러\n- [ ] API 통신\n- [ ] 유틸리티 함수',
    'pages': '- [ ] HTML 페이지 구조\n- [ ] 페이지별 기능 구현\n- [ ] SEO 최적화\n- [ ] 접근성 개선',
    'public': '- [ ] 이미지 리소스 관리\n- [ ] 폰트 파일 관리\n- [ ] 정적 자산 최적화\n- [ ] 리소스 로딩 최적화',

    // Phase 3: 개발 - 인증
    'Email_Auth': '- [ ] 이메일 회원가입\n- [ ] 이메일 인증\n- [ ] 비밀번호 암호화\n- [ ] 로그인/로그아웃',
    'Google_OAuth': '- [ ] Google OAuth 설정\n- [ ] OAuth 플로우 구현\n- [ ] 사용자 정보 연동\n- [ ] 토큰 관리',
    'Session_Management': '- [ ] 세션 생성 및 저장\n- [ ] 세션 검증\n- [ ] 세션 만료 처리\n- [ ] 보안 강화',

    // Phase 3: 개발 - 백엔드
    '백엔드 인프라': '- [ ] 서버 구조 설계\n- [ ] API 서버 구축\n- [ ] 미들웨어 설정\n- [ ] 에러 핸들링',

    // Phase 3: 개발 - 데이터베이스
    'scripts': '- [ ] 마이그레이션 스크립트\n- [ ] 시드 데이터 생성\n- [ ] 롤백 스크립트\n- [ ] 백업 스크립트',

    // Phase 3: 개발 - 외부 서비스
    'Email': '- [ ] 이메일 서비스 연동\n- [ ] 템플릿 작성\n- [ ] 발송 로직 구현\n- [ ] 발송 테스트',
    'Payments': '- [ ] 결제 게이트웨이 연동\n- [ ] 결제 플로우 구현\n- [ ] Webhook 처리\n- [ ] 결제 테스트',

    // Phase 3: 개발 - 테스트
    '1_api': '- [ ] API 테스트 케이스 작성\n- [ ] 요청/응답 검증\n- [ ] 에러 케이스 테스트\n- [ ] 테스트 자동화',
    '2_auth': '- [ ] 인증 플로우 테스트\n- [ ] 권한 검증 테스트\n- [ ] 세션 테스트\n- [ ] 보안 테스트',
    '3_e2e': '- [ ] E2E 테스트 시나리오 작성\n- [ ] 테스트 자동화\n- [ ] 주요 플로우 검증\n- [ ] 브라우저 호환성 테스트',
    '4_integration': '- [ ] 통합 테스트 케이스\n- [ ] 컴포넌트 간 연동 테스트\n- [ ] 외부 서비스 연동 테스트\n- [ ] 통합 테스트 자동화',
    '5_unit': '- [ ] 단위 테스트 작성\n- [ ] 테스트 커버리지 확보\n- [ ] 엣지 케이스 테스트\n- [ ] Mock/Stub 활용',

    // Phase 3: 개발 - 배포
    '.github': '- [ ] GitHub Actions 워크플로우\n- [ ] 자동 빌드 설정\n- [ ] 자동 배포 설정\n- [ ] 알림 설정',
    'CI_CD': '- [ ] CI 파이프라인 구축\n- [ ] CD 파이프라인 구축\n- [ ] 테스트 자동화 통합\n- [ ] 배포 전략 수립',
    'Environment_Variables': '- [ ] 환경별 변수 정의\n- [ ] 시크릿 관리\n- [ ] 환경 변수 암호화\n- [ ] 변수 문서화',
    'Production_Config': '- [ ] 프로덕션 설정 최적화\n- [ ] 보안 설정\n- [ ] 성능 설정\n- [ ] 로깅 설정',
    'Vercel_Deploy': '- [ ] Vercel 배포 설정\n- [ ] 배포 자동화\n- [ ] 프리뷰 배포 설정\n- [ ] 도메인 연결',

    // Phase 3: 개발 - 안정화
    'Hotfix': '- [ ] 긴급 이슈 파악\n- [ ] 핫픽스 개발\n- [ ] 긴급 배포\n- [ ] 사후 분석',
    'Patch': '- [ ] 버그 수정\n- [ ] 패치 버전 업데이트\n- [ ] 패치 노트 작성\n- [ ] 패치 배포',
    'Performance_Tuning': '- [ ] 성능 프로파일링\n- [ ] 병목 지점 식별\n- [ ] 최적화 적용\n- [ ] 성능 검증',
    'Troubleshooting': '- [ ] 이슈 재현\n- [ ] 원인 분석\n- [ ] 해결 방안 수립\n- [ ] 해결 및 검증'
  };

  return scopes[name] || '- [ ] 작업 항목 1\n- [ ] 작업 항목 2\n- [ ] 작업 항목 3';
}

// 주요 고려사항 생성
function getConsiderations(name, parent) {
  const considerations = {
    // Phase 1: 기획
    '디렉토리 구조': '1. 확장 가능한 구조\n2. 명확한 네이밍\n3. 표준 규칙 준수',
    'requirements': '1. 명확성과 완결성\n2. 측정 가능성\n3. 우선순위 기반 구현',
    'user_flows': '1. 사용자 관점 중심\n2. 예외 상황 처리\n3. 플로우 간 일관성',
    'workflows': '1. 효율성과 정확성\n2. 자동화 가능성\n3. 변경 가능성',
    '디자인 가이드라인': '1. 일관성 유지\n2. 접근성 고려\n3. 반응형 디자인',
    '목업': '1. 사용자 경험\n2. 디자인 시스템 준수\n3. 반응형 레이아웃',
    '프로토타입': '1. 인터랙션 품질\n2. 사용성 테스트\n3. 피드백 반영',
    '데이터베이스 설계': '1. 정규화\n2. 성능 최적화\n3. 확장성',

    // Phase 2: 개발준비
    'Docker': '1. 이미지 크기 최적화\n2. 레이어 캐싱\n3. 보안',
    'Environment': '1. 환경별 분리\n2. 시크릿 보안\n3. 문서화',
    'Git': '1. 브랜치 전략\n2. 커밋 컨벤션\n3. 코드 리뷰 프로세스',
    'Node': '1. 버전 호환성\n2. 의존성 관리\n3. 보안 취약점',
    'Supabase': '1. 보안 설정\n2. 성능 최적화\n3. 비용 관리',
    'Vercel': '1. 빌드 최적화\n2. 환경 변수 관리\n3. 배포 전략',
    'manual': '1. 명확성\n2. 완결성\n3. 업데이트 용이성',
    'project_grid': '1. 구조 일관성\n2. 확장 가능성\n3. 유지보수성',
    'scripts': '1. 재사용성\n2. 에러 핸들링\n3. 로깅',
    'tasks': '1. 명확한 정의\n2. 의존성 관리\n3. 추적 가능성',
    'validation': '1. 정확성\n2. 성능\n3. 자동화',

    // Phase 3: 개발 - 프론트엔드
    'css': '1. 성능 최적화\n2. 유지보수성\n3. 브라우저 호환성',
    'js': '1. 코드 품질\n2. 성능\n3. 에러 핸들링',
    'pages': '1. SEO\n2. 접근성\n3. 성능',
    'public': '1. 로딩 최적화\n2. 캐싱 전략\n3. CDN 활용',

    // Phase 3: 개발 - 인증
    'Email_Auth': '1. 보안\n2. 사용자 경험\n3. 에러 처리',
    'Google_OAuth': '1. OAuth 2.0 표준 준수\n2. 토큰 보안\n3. 에러 핸들링',
    'Session_Management': '1. 세션 보안\n2. 성능\n3. 확장성',

    // Phase 3: 개발 - 백엔드
    '백엔드 인프라': '1. 확장성\n2. 안정성\n3. 보안',

    // Phase 3: 개발 - 데이터베이스
    'scripts': '1. 멱등성\n2. 롤백 가능성\n3. 테스트',

    // Phase 3: 개발 - 외부 서비스
    'Email': '1. 발송 성공률\n2. 스팸 필터 회피\n3. 템플릿 관리',
    'Payments': '1. 보안\n2. PCI DSS 준수\n3. 에러 처리',

    // Phase 3: 개발 - 테스트
    '1_api': '1. 테스트 커버리지\n2. 테스트 격리\n3. 자동화',
    '2_auth': '1. 보안 테스트\n2. 엣지 케이스\n3. 자동화',
    '3_e2e': '1. 실제 사용자 시나리오\n2. 안정성\n3. 실행 시간',
    '4_integration': '1. 테스트 격리\n2. Mock 활용\n3. 자동화',
    '5_unit': '1. 테스트 독립성\n2. 커버리지\n3. 속도',

    // Phase 3: 개발 - 배포
    '.github': '1. 자동화\n2. 보안\n3. 알림',
    'CI_CD': '1. 빌드 속도\n2. 안정성\n3. 롤백 전략',
    'Environment_Variables': '1. 보안\n2. 관리 편의성\n3. 문서화',
    'Production_Config': '1. 성능 최적화\n2. 보안 강화\n3. 모니터링',
    'Vercel_Deploy': '1. 배포 속도\n2. 자동화\n3. 롤백 전략',

    // Phase 3: 개발 - 안정화
    'Hotfix': '1. 신속성\n2. 정확성\n3. 사후 분석',
    'Patch': '1. 하위 호환성\n2. 테스트\n3. 문서화',
    'Performance_Tuning': '1. 측정 기반 최적화\n2. 사용자 경험\n3. 리소스 효율',
    'Troubleshooting': '1. 체계적 접근\n2. 문서화\n3. 재발 방지'
  };

  return considerations[name] || '1. 고려사항 1\n2. 고려사항 2\n3. 고려사항 3';
}

// 산출물 생성
function getDeliverables(name, parent) {
  const deliverables = {
    // Phase 1: 기획
    '디렉토리 구조': '- PROJECT_DIRECTORY_STRUCTURE.md\n- 디렉토리 구조 다이어그램',
    'requirements': '- 요구사항 명세서\n- 사용자 스토리\n- 우선순위 문서',
    'user_flows': '- 사용자 플로우 다이어그램\n- 플로우 설명 문서',
    'workflows': '- 워크플로우 다이어그램\n- 프로세스 문서',
    '디자인 가이드라인': '- 디자인 가이드 문서\n- 컴포넌트 라이브러리',
    '목업': '- 화면 목업 파일\n- 목업 설명 문서',
    '프로토타입': '- 인터랙티브 프로토타입\n- 사용성 테스트 리포트',
    '데이터베이스 설계': '- ERD 다이어그램\n- 스키마 문서',

    // Phase 2: 개발준비
    'Docker': '- Dockerfile\n- docker-compose.yml',
    'Environment': '- .env 템플릿\n- 환경 변수 문서',
    'Git': '- .gitignore\n- 브랜치 전략 문서',
    'Node': '- package.json\n- package-lock.json',
    'Supabase': '- Supabase 설정 문서\n- 연동 가이드',
    'Vercel': '- Vercel 설정 파일\n- 배포 가이드',
    'manual': '- 프로젝트 그리드 매뉴얼',
    'project_grid': '- 프로젝트 그리드 구조 파일',
    'scripts': '- 자동화 스크립트 파일',
    'tasks': '- Task 정의 파일',
    'validation': '- 검증 스크립트\n- 검증 리포트',

    // Phase 3: 개발 - 프론트엔드
    'css': '- CSS 파일\n- 스타일 가이드',
    'js': '- JavaScript 파일\n- 함수 문서',
    'pages': '- HTML 페이지\n- 페이지 문서',
    'public': '- 이미지 파일\n- 폰트 파일\n- 기타 정적 리소스',

    // Phase 3: 개발 - 인증
    'Email_Auth': '- 인증 API\n- 인증 컴포넌트\n- 인증 문서',
    'Google_OAuth': '- OAuth 연동 코드\n- OAuth 설정 문서',
    'Session_Management': '- 세션 관리 코드\n- 세션 정책 문서',

    // Phase 3: 개발 - 백엔드
    '백엔드 인프라': '- 서버 코드\n- API 문서\n- 인프라 구성도',

    // Phase 3: 개발 - 데이터베이스
    'scripts': '- 마이그레이션 스크립트\n- 시드 스크립트',

    // Phase 3: 개발 - 외부 서비스
    'Email': '- 이메일 발송 코드\n- 이메일 템플릿',
    'Payments': '- 결제 연동 코드\n- 결제 플로우 문서',

    // Phase 3: 개발 - 테스트
    '1_api': '- API 테스트 코드\n- 테스트 리포트',
    '2_auth': '- 인증 테스트 코드\n- 테스트 리포트',
    '3_e2e': '- E2E 테스트 코드\n- 테스트 리포트',
    '4_integration': '- 통합 테스트 코드\n- 테스트 리포트',
    '5_unit': '- 단위 테스트 코드\n- 커버리지 리포트',

    // Phase 3: 개발 - 배포
    '.github': '- GitHub Actions 워크플로우 파일',
    'CI_CD': '- CI/CD 파이프라인 설정\n- 배포 문서',
    'Environment_Variables': '- 환경 변수 목록\n- 관리 문서',
    'Production_Config': '- 프로덕션 설정 파일\n- 설정 문서',
    'Vercel_Deploy': '- Vercel 배포 설정\n- 배포 가이드',

    // Phase 3: 개발 - 안정화
    'Hotfix': '- 핫픽스 코드\n- 사후 분석 문서',
    'Patch': '- 패치 코드\n- 패치 노트',
    'Performance_Tuning': '- 최적화 코드\n- 성능 분석 리포트',
    'Troubleshooting': '- 해결 방안 문서\n- 이슈 분석 리포트'
  };

  return deliverables[name] || '- 산출물 1\n- 산출물 2';
}

// TODO를 실제 템플릿으로 교체
let updated = 0;
Object.keys(templates).forEach(key => {
  if (templates[key].template === 'TODO') {
    const name = templates[key].name;
    const parent = templates[key].parent;
    templates[key].template = createTemplate(name, parent);
    updated++;
    console.log(`✅ ${key} - 템플릿 생성 완료`);
  }
});

// 저장
fs.writeFileSync(templatesPath, JSON.stringify(templates, null, 2), 'utf8');

console.log('');
console.log('✅ 전체 완료!');
console.log(`생성된 템플릿 수: ${updated}개`);
console.log(`총 템플릿 수: ${Object.keys(templates).length}개`);
