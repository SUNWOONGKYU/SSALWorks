# Human-ClaudeCode Bridge 시스템 가이드

> **작성일**: 2025-12-18
> **버전**: 2.1
> **목적**: 사람과 Claude Code 간의 작업 요청/결과 확인 전체 플로우 가이드

---

## 1. 시스템 개요

### 1.1 Human-ClaudeCode Bridge란?

**Human-ClaudeCode Bridge**는 사용자(Human)와 Claude Code AI 간의 작업 요청 및 결과 확인을 위한 시스템입니다.

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Human-ClaudeCode Bridge 플로우                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│   [Dashboard]                                                        │
│       │                                                              │
│       ├─ Order Sheet 작성 ──────────────────┐                        │
│       │                                      │                       │
│       ├─ [Order Sheet 전달하기] 버튼 ────────┤                        │
│       │         │                            │                       │
│       │         ├─► 📋 클립보드에 복사 ──────┼──► Claude Code 붙여넣기 │
│       │         │                            │                       │
│       │         └─► 💾 Orders 폴더에 저장 ───┼──► JSON 다운로드       │
│       │                                      │                       │
│       │                                      ▼                       │
│       │                              [Claude Code]                   │
│       │                                      │                       │
│       │                              작업 수행                       │
│       │                                      │                       │
│       │                                      ▼                       │
│       │                              [Orders/ 폴더]                  │
│       │                              Order 원본 저장                 │
│       │                                      │                       │
│       │                                      ▼                       │
│       │                              [Reports/ 폴더]                 │
│       │                              작업 결과 저장                  │
│       │                                      │                       │
│       │                                      │                       │
│       └─ [Reports 불러오기] 버튼 ◄───────────┘                       │
│               │                                                      │
│               ▼                                                      │
│       HTML 모달로 결과 확인                                          │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

### 1.2 폴더 구조

```
Human_ClaudeCode_Bridge/
├── Orders/                    ← Claude Code가 받은 Order Sheet 저장
│   └── *.json, *.md
├── Reports/                   ← Claude Code 작업 결과 저장
│   └── *.json, *.md
├── inbox_server.js            ← 로컬 개발용 서버
└── HUMAN_CLAUDECODE_BRIDGE_GUIDE.md  ← 이 문서
```

### 1.3 핵심 특징

| 특징 | 설명 |
|------|------|
| **단방향 복사** | Dashboard → Claude Code (클립보드 복사) |
| **양방향 저장** | Orders(요청) / Reports(결과) 분리 저장 |
| **HTML 렌더링** | JSON/MD 파일을 보기 좋은 HTML로 변환 |
| **프로덕션 지원** | File System Access API로 로컬 파일 선택 |

### 1.4 메모리/컨텍스트 관리 이점

> **"모든 작업이 JSON으로 저장된다 = 완벽한 메모리"**
> **"세션 간 연속성 유지 = AI 기억 100%"**

**이 시스템의 핵심 가치: Claude Code 세션 간 정보 연속성 확보**

```
┌─────────────────────────────────────────────────────────────────────┐
│                    💡 Orders/Reports 시스템의 메모리 이점            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ❌ 기존 방식의 문제점                                               │
│  ─────────────────────────────────────────────────────────────────   │
│  채팅 방식:                                                          │
│  - 대화 컨텍스트 길이 제한 (토큰 한계)                               │
│  - 세션 종료 시 대화 내용 휘발                                       │
│  - 세션 끊기면 컨텍스트 손실                                         │
│  - 작업 추적 어려움                                                  │
│                                                                      │
│  work_log 방식:                                                      │
│  - 비구조화된 텍스트                                                 │
│  - 검색 어려움 (전체 텍스트 검색만)                                  │
│  - 통계 추출 불가능                                                  │
│  - 자동화 어려움                                                     │
│                                                                      │
│  ✅ Orders/Reports JSON 시스템의 해결책                              │
│  ─────────────────────────────────────────────────────────────────   │
│  - 구조화된 JSON 형식 = 필드별 즉시 검색 가능                        │
│  - 작업 요청 → Orders 폴더에 영구 저장                               │
│  - 작업 결과 → Reports 폴더에 영구 저장                              │
│  - 새 세션에서도 이전 작업 기록 참조 가능                            │
│  - 컨텍스트 오버플로우 방지                                          │
│  - 통계 자동 추출                                                    │
│  - 프로그래밍 가능 (자동화)                                          │
│                                                                      │
│  📊 효과                                                             │
│  ─────────────────────────────────────────────────────────────────   │
│  - 메모리 문제 해결: 긴 대화도 파일로 분산 저장                      │
│  - 작업 추적 가능: 언제 무엇을 요청했는지 기록 유지                  │
│  - 세션 독립성: 세션이 끊어져도 작업 기록 보존                       │
│  - 검색 가능: 과거 Orders/Reports 검색하여 참조                      │
│  - 세션 간 완벽한 연속성                                             │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

### 방식별 비교표

| 항목 | 채팅 방식 | work_log | Orders/Reports JSON |
|------|----------|----------|---------------------|
| **명확성** | ❌ 모호 | △ 보통 | ✅ 명확 |
| **구조화** | ❌ 없음 | ❌ 없음 | ✅ 완벽 |
| **검색** | ❌ 어려움 | △ 텍스트만 | ✅ 필드별 |
| **통계** | ❌ 불가능 | ❌ 수동 | ✅ 자동 |
| **웹 연동** | ❌ 없음 | ❌ 어려움 | ✅ 자동 |
| **자동화** | ❌ 불가능 | ❌ 어려움 | ✅ 쉬움 |
| **연속성** | ❌ 끊김 | △ 제한적 | ✅ 완벽 |
| **AI 기억** | ❌ 제한 | △ 부분적 | ✅ 100% |

**실제 활용 예시:**

| 상황 | Orders/Reports 없이 | Orders/Reports 사용 |
|------|---------------------|---------------------|
| 긴 작업 중 세션 만료 | ❌ 처음부터 다시 설명 | ✅ Orders 파일로 이어서 작업 |
| 이전 작업 결과 참조 | ❌ 기억에 의존 | ✅ Reports 파일에서 확인 |
| 여러 Task 관리 | ❌ 대화로 추적 | ✅ Orders/Reports 파일로 관리 |
| 작업 히스토리 | ❌ 스크롤해서 찾기 | ✅ 폴더에서 날짜별 검색 |
| 통계 분석 | ❌ 수동 계산 | ✅ JSON 자동 집계 |

---

## 2. 전체 프로세스 플로우

### 2.1 Step 1: Order Sheet 작성

**Dashboard에서 Order Sheet를 작성합니다.**

1. SSAL Works Dashboard 접속
2. Workspace 영역에 Order Sheet 작성
3. 또는 사이드바에서 템플릿 선택하여 자동 로드

**Order Sheet 예시:**
```markdown
# Order Sheet - S2F1 로그인 페이지 UI

## 기본 정보
- **Task ID**: S2F1
- **작성일**: 2025-12-18
- **우선순위**: 높음

## 작업 요청 내용

### 목표
사용자 로그인 페이지 UI 구현

### 기능 요구사항
- 이메일/비밀번호 입력 필드
- 로그인 버튼
- Google 로그인 버튼
- 비밀번호 찾기 링크

### 산출물
- Production/Frontend/pages/auth/login.html

## 참고사항
- 기존 디자인 시스템 준수
- 반응형 디자인 적용

## 필수 참조 규칙
- `.claude/rules/01_file-naming.md` - 파일 명명 규칙
- `.claude/rules/02_save-location.md` - 저장 위치 규칙
- `.claude/rules/05_execution-process.md` - 실행 프로세스
```

### 2.2 Step 2: Order Sheet 전달하기

**[Order Sheet 전달하기] 버튼을 클릭합니다.**

```
┌──────────────────────────────────────────────┐
│  Workspace 영역                               │
│  ┌────────────────────────────────────────┐  │
│  │ # Order Sheet - S2F1 로그인 페이지 UI  │  │
│  │ ...                                    │  │
│  └────────────────────────────────────────┘  │
│                                              │
│  ┌─────────────┐ ┌─────────────┐ ┌────────┐  │
│  │ Workspace   │ │ Order Sheet │ │Reports │  │
│  │ 지우기      │ │ 전달하기    │ │불러오기│  │
│  │ (회색)      │ │ (초록색)    │ │(파란색)│  │
│  └─────────────┘ └─────────────┘ └────────┘  │
└──────────────────────────────────────────────┘
```

**버튼 클릭 시 옵션 선택 모달이 표시됩니다:**

```
┌─────────────────────────────────────────────────┐
│ 📤 Order Sheet 전달하기                          │
│    전달 방식을 선택하세요                         │
├─────────────────────────────────────────────────┤
│                                                  │
│  ┌───────────────────────────────────────────┐  │
│  │ 💾 Orders 폴더에 저장                      │  │
│  │    Human_ClaudeCode_Bridge/Orders/에       │  │
│  │    JSON 파일로 저장됩니다                  │  │
│  └───────────────────────────────────────────┘  │
│                                                  │
│  ┌───────────────────────────────────────────┐  │
│  │ 📋 클립보드에 복사                         │  │
│  │    복사 후 Claude Code에 직접              │  │
│  │    붙여넣기 하세요                         │  │
│  └───────────────────────────────────────────┘  │
│                                                  │
├─────────────────────────────────────────────────┤
│                                      [취소]      │
└─────────────────────────────────────────────────┘
```

#### 옵션 1: Orders 폴더에 저장 💾

- **JSON 파일 다운로드**: `ORDER_YYYY-MM-DDTHH-MM-SS.json`
- **저장 경로**: `[프로젝트폴더]/Human_ClaudeCode_Bridge/Orders/`
- **파일 구조**:
  ```json
  {
    "type": "order_sheet",
    "created_at": "2025-12-18T10:30:00.000Z",
    "content": "# Order Sheet 내용...",
    "metadata": {
      "source": "SSAL Works Dashboard",
      "version": "1.0"
    }
  }
  ```
- **저장 방법**:
  - ⭐ **처음**: 위 경로를 찾아서 저장해주세요
  - ⭐ **이후**: 자동으로 지정된 폴더가 열립니다

#### 옵션 2: 클립보드에 복사 📋

- **클립보드에 Order Sheet 내용이 복사됩니다**
- 상태바에 "✅ Order Sheet 복사 완료" 표시
- Claude Code **CLI 창**에 직접 붙여넣기 (`Ctrl+V`)

### 2.3 Step 3: Claude Code에 붙여넣기

**Claude Code에서 Order Sheet를 붙여넣고 작업을 요청합니다.**

1. Claude Code 터미널 또는 대화창 열기
2. `Ctrl+V`로 Order Sheet 붙여넣기
3. 필요시 추가 지시사항 입력
4. Enter로 작업 요청

**Claude Code 대화 예시:**
```
사용자: [Order Sheet 붙여넣기]

Claude Code: Order Sheet를 확인했습니다. S2F1 로그인 페이지 UI 작업을 시작하겠습니다.

1. Orders 폴더에 Order Sheet 저장
2. 로그인 페이지 UI 구현
3. 작업 결과를 Reports 폴더에 저장

작업을 진행하겠습니다.
```

### 2.4 Step 4: Claude Code 작업 수행

**Claude Code가 작업을 수행합니다.**

```
Claude Code 작업 순서:
┌───────────────────────────────────────────────────────┐
│ 1. Order Sheet를 Orders/ 폴더에 저장 (원칙!)          │
│    → Human_ClaudeCode_Bridge/Orders/S2F1_order.json  │
├───────────────────────────────────────────────────────┤
│ 2. 실제 작업 수행                                     │
│    → 코드 작성, 파일 생성, 테스트 등                  │
├───────────────────────────────────────────────────────┤
│ 3. 작업 결과를 Reports/ 폴더에 저장                   │
│    → Human_ClaudeCode_Bridge/Reports/S2F1_report.json│
└───────────────────────────────────────────────────────┘
```

### 2.5 Step 5: Reports 불러오기

**Dashboard에서 [Reports 불러오기] 버튼을 클릭합니다.**

1. **[Reports 불러오기]** 버튼 클릭 (파란색 버튼)
2. 안내 팝업 확인:
   ```
   📂 Report 파일 선택 안내

   경로: [프로젝트폴더]/Human_ClaudeCode_Bridge/Reports/

   위 폴더에서 Report 파일(.json 또는 .md)을 선택하시면
   HTML 파일로 보기 좋게 변환하여 볼 수 있습니다.
   ```
3. 파일 선택 다이얼로그에서 Report 파일 선택
4. HTML 모달로 결과 확인

### 2.6 Step 6: HTML 모달에서 결과 확인

**선택한 파일이 HTML로 렌더링되어 모달에 표시됩니다.**

| 파일 유형 | 렌더링 방식 |
|-----------|-------------|
| `.json` | 카드/테이블 형태로 변환, 주요 필드(task_id, status 등) 상단 배지 표시 |
| `.md` | marked.js로 HTML 변환, 스타일 적용 (헤딩, 코드블록, 테이블 등) |

```
┌─────────────────────────────────────────────────────┐
│ 📄 S2F1_report.json                            [X]  │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ┌─────────┐ ┌──────────────┐ ┌────────┐           │
│  │  S2F1   │ │ 로그인 페이지 │ │  완료  │           │
│  └─────────┘ └──────────────┘ └────────┘           │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │ task_id      │ S2F1                         │   │
│  │ task_name    │ 로그인 페이지 UI              │   │
│  │ status       │ 완료                          │   │
│  │ files        │ login.html, login.css        │   │
│  │ created_at   │ 2025-12-18T10:30:00Z         │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
│                                        [닫기]       │
└─────────────────────────────────────────────────────┘
```

---

## 3. Dashboard 버튼 설명

### 3.1 버튼 구성

| 버튼 | 색상 | 기능 |
|------|------|------|
| **Workspace 지우기** | 회색 | Workspace 내용 초기화 |
| **Order Sheet 복사하기** | 초록색 | Workspace 내용을 클립보드에 복사 |
| **Reports 불러오기** | 파란색 | Reports 폴더에서 파일 선택하여 HTML로 보기 |

### 3.2 Reports 불러오기 상세

**프로덕션 환경 (Vercel 배포):**
- File System Access API 사용
- 로컬 파일 시스템에서 직접 파일 선택
- 브라우저가 마지막 폴더 위치 기억

**로컬 개발 환경:**
- Bridge 서버 (`inbox_server.js`) 사용
- `http://localhost:3030` API 호출
- 파일 목록 모달에서 선택

---

## 4. 파일 저장 규칙

### 4.1 파일 형식 규칙 (중요!)

| 파일 종류 | 형식 | 이유 |
|----------|------|------|
| **Order Sheet** | `.json` | 구조화된 데이터 (Task ID, 의존성, 작업 내용 등) |
| **작업 완료 보고서** | `.json` | AI가 다음 세션에서 파싱하여 이전 작업 파악 |
| **검증 리포트** | `.json` | 테스트 결과, 점수, 체크리스트 등 구조화된 데이터 |
| **요약 문서 (선택)** | `.md` | 사람이 읽기 편한 설명 (필요시만 추가) |

```
⚠️ 기본 원칙: JSON을 기본으로 사용

이유:
1. AI 메모리 활용 - 다음 세션에서 파싱하여 이전 작업 파악
2. 구조화된 데이터 - 상태, 파일 목록, 검증 결과 등 명확히 구분
3. 일관성 - Order(JSON) → Report(JSON) 동일한 형식
4. 자동화 - 프로그래밍으로 처리 가능
```

### 4.2 Orders 폴더 (요청)

**Claude Code가 Order Sheet를 받으면 반드시 JSON으로 저장:**

```
Human_ClaudeCode_Bridge/Orders/
├── S2F1_order.json          ← Task ID 기반 파일명 (권장)
├── S2BA1_order.json
├── ORDER-GE-251218-01.json  ← Order ID 기반 파일명
└── ...
```

**Order Sheet JSON 구조:**
```json
{
  "order_id": "ORDER-S2F1-251218",
  "task_id": "S2F1",
  "task_name": "로그인 페이지 UI",
  "priority": "높음",
  "created_at": "2025-12-18T10:00:00Z",
  "instructions": "...",
  "expected_output": ["Production/Frontend/pages/auth/login.html"],
  "dependencies": ["S1D1"],
  "rules_reference": [
    ".claude/rules/01_file-naming.md",
    ".claude/rules/02_save-location.md",
    ".claude/rules/05_execution-process.md"
  ]
}
```

**Order Sheet JSON 필드 설명:**

| 필드 | 설명 | 필수 여부 |
|------|------|----------|
| `order_id` | Order 고유 ID | ✅ |
| `task_id` | Grid Task ID (S2F1 등) | ✅ |
| `task_name` | Task 이름 | ✅ |
| `priority` | 우선순위 (높음/중간/낮음) | ⭕ 선택 |
| `created_at` | 생성 시간 (ISO 8601) | ✅ |
| `instructions` | 작업 지시사항 | ✅ |
| `expected_output` | 예상 결과물 파일 목록 | ✅ |
| `dependencies` | 선행 Task ID 목록 | ⭕ 선택 |
| `rules_reference` | **필수 참조 규칙 파일 목록** | ✅ |

**rules_reference 필드 (2025-12-19 추가):**

> **⚠️ 중요: 모든 Order Sheet에 반드시 포함해야 합니다!**

Task 유형에 따라 적절한 규칙 파일을 참조합니다:

| Task Area | 필수 규칙 파일 |
|-----------|---------------|
| **모든 Task** | `01_file-naming.md`, `02_save-location.md`, `05_execution-process.md` |
| **F, BA, D** | + `03_area-stage.md` (Production 이중 저장) |
| **검증 관련** | + `04_grid-writing-supabase.md`, `06_verification.md` |

### 4.3 Reports 폴더 (결과)

**Claude Code가 작업 완료 후 JSON으로 저장:**

```
Human_ClaudeCode_Bridge/Reports/
├── S2F1_completed.json      ← 작업 완료 보고서 (필수)
├── S2F1_verification.json   ← 검증 결과 (필수)
├── S2F1_summary.md          ← 요약 문서 (선택, 필요시만)
└── ...
```

**작업 완료 보고서 JSON 구조:**
```json
{
  "order_id": "ORDER-S2F1-251218",
  "task_id": "S2F1",
  "task_name": "로그인 페이지 UI",
  "status": "completed",
  "files_created": [
    "Production/Frontend/pages/auth/login.html"
  ],
  "verification": {
    "test": "✅ 10/10 통과",
    "build": "✅ 성공"
  },
  "completed_at": "2025-12-18T11:30:00Z"
}
```

**MD 파일은 언제 사용?**
- 사람이 읽기 편한 상세 설명이 필요할 때
- 긴 설명, 스크린샷 링크, 상세 가이드 등
- 기본 JSON 보고서의 **보충 자료**로만 사용

---

## 5. Report 파일 형식

### 5.1 JSON 형식 예시

```json
{
  "task_id": "S2F1",
  "task_name": "로그인 페이지 UI",
  "status": "완료",
  "created_at": "2025-12-18T10:30:00Z",
  "completed_at": "2025-12-18T11:45:00Z",

  "files_created": [
    "Production/Frontend/pages/auth/login.html",
    "Production/Frontend/assets/css/auth.css"
  ],

  "verification": {
    "build": "✅ 성공",
    "lint": "✅ 오류 없음",
    "test": "✅ 통과"
  },

  "summary": "로그인 페이지 UI 구현 완료. 이메일/비밀번호 입력, Google 로그인, 비밀번호 찾기 기능 포함.",

  "next_steps": [
    "S2BA1 - 로그인 API 구현",
    "S2F2 - 회원가입 페이지 UI"
  ]
}
```

### 5.2 Markdown 형식 예시

```markdown
# S2F1 작업 완료 보고서

## 기본 정보
- **Task ID**: S2F1
- **Task Name**: 로그인 페이지 UI
- **Status**: 완료
- **완료 시간**: 2025-12-18 11:45

## 생성된 파일
- `Production/Frontend/pages/auth/login.html`
- `Production/Frontend/assets/css/auth.css`

## 구현 내용
1. 이메일/비밀번호 입력 폼
2. 로그인 버튼
3. Google 로그인 버튼
4. 비밀번호 찾기 링크

## 검증 결과
- ✅ 빌드 성공
- ✅ Lint 오류 없음
- ✅ 반응형 테스트 통과

## 다음 단계
- S2BA1: 로그인 API 구현
- S2F2: 회원가입 페이지 UI
```

---

## 6. 환경별 동작

### 6.1 프로덕션 환경 (Vercel)

```
┌────────────────────────────────────────────┐
│ 프로덕션 환경                               │
├────────────────────────────────────────────┤
│ - File System Access API 사용              │
│ - showOpenFilePicker() 호출               │
│ - 로컬 파일 직접 선택                      │
│ - 서버 연결 불필요                         │
│ - 브라우저가 폴더 위치 기억                │
└────────────────────────────────────────────┘
```

### 6.2 로컬 개발 환경

```
┌────────────────────────────────────────────┐
│ 로컬 개발 환경                              │
├────────────────────────────────────────────┤
│ - Bridge 서버 실행 필요                    │
│   cd Human_ClaudeCode_Bridge               │
│   node inbox_server.js                     │
│                                            │
│ - http://localhost:3030 API 호출          │
│ - 파일 목록 모달 표시                      │
│ - 실시간 알림 지원 (Socket.io)            │
└────────────────────────────────────────────┘
```

---

## 7. 자주 묻는 질문 (FAQ)

### Q1. Reports 불러오기가 안 돼요

**A1.** 브라우저가 File System Access API를 지원하는지 확인하세요.
- ✅ Chrome 86+
- ✅ Edge 86+
- ❌ Firefox (미지원)
- ❌ Safari (미지원)

### Q2. 파일이 열리지 않아요

**A2.** 지원 파일 형식을 확인하세요.
- ✅ `.json` 파일
- ✅ `.md` 파일
- ❌ 기타 형식

### Q3. 모달이 안 뜨고 에러가 나요

**A3.** 브라우저 콘솔에서 에러 메시지를 확인하세요.
- `marked is not defined` → marked.js 로드 필요
- `showOpenFilePicker is not defined` → 브라우저 미지원

### Q4. 로컬에서 서버 연결이 안 돼요

**A4.** Bridge 서버를 실행하세요.
```bash
cd Human_ClaudeCode_Bridge
node inbox_server.js
```
`http://localhost:3030` 접속하여 확인

---

## 8. 버전 이력

| 버전 | 날짜 | 변경 내용 |
|------|------|----------|
| 1.0 | 2025-11-18 | 최초 작성 (Inbox/Outbox 시스템) |
| 2.0 | 2025-12-18 | 전면 개편 - Orders/Reports 체계, HTML 렌더링 기능 추가 |
| 2.1 | 2025-12-18 | Order Sheet 전달하기 기능 추가 (저장/복사 옵션 선택) |
| 2.2 | 2025-12-19 | Order Sheet 규칙 참조 필드 추가 (`.claude/rules/` 연동) |

---

**작성자**: Claude Code
**최종 수정**: 2025-12-18
