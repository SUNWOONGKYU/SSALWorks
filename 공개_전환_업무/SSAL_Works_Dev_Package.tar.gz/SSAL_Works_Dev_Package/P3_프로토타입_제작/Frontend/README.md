# P3 Frontend - 프로토타입 제작

## 폴더 구조

```
Frontend/
└── Prototype/     # 프로토타입 HTML/JS/CSS 파일
```

## 설명

이 폴더는 SSALWORKS 프로토타입 프론트엔드 코드를 포함합니다.

- **Prototype/**: 실제 프로토타입 파일들 (HTML, JS, CSS)

## 참고

Production 폴더와 동기화되어 있습니다.
