# User Flows Summary for Mockup Integration

**Source:** `P2_프로젝트_기획\1-2_User_Flows\`
**Extracted:** 2025-12-03
**Purpose:** Summary of all 8+ User Flow documents for mockup creation

---

## Overview

SSAL Works has **8 main User Flow folders** plus additional guides:

1. **1_Signup** - 회원가입
2. **2_Project_Registration** - 프로젝트 등록
3. **3_Subscription** - 구독 관리
4. **4_Credit_Purchase** - 크레딧 충전
5. **5_Project_Development** - 프로젝트 개발
6. **6_AI_QA** - AI 질문하기
7. **7_AI_Integration** - AI 연동
8. **8_Support** - 지원/문의

Plus:
- **5_Books_Learning** - 학습 콘텐츠
- **5_Home_Screen_User_Guide.md** - 11개 영역 상세 가이드

---

## 1. Home Screen - 11개 영역 구조

**Source:** `5_Home_Screen_User_Guide.md`

### 레이아웃 구조
```
┌─────────────────────────────────────────────────────────────────┐
│  SSAL Works Dashboard                                           │
├──────────┬───────────────────────────────────┬──────────────────┤
│  좌측    │        중앙 워크스페이스           │    우측          │
│ 사이드바 │                                   │   사이드바       │
│          │                                   │                  │
│ ① 📦 PROJECT    │ ④ Workspace (상단 75%)      │ ⑥ 📚 학습 콘텐츠  │
│ ② 📊 진행       │ ⑤ Project SAL Grid          │ ⑦ 🙋 FAQ         │
│    프로세스     │    (하단 25%)               │ ⑧ 🔔 Claude Code │
│ ③ 🔗 연계       │                              │    업데이트      │
│    서비스       │                              │ ⑨ 🤖 AI묻기      │
│    바로가기     │                              │ ⑩ ☀️ Sunny묻기   │
│                 │                              │ ⑪ 📢 공지사항    │
└──────────┴───────────────────────────────────┴──────────────────┘
```

### 좌측 사이드바 (3개 영역)

#### 영역 ① 📦 PROJECT
- **목적:** 내가 만든 모든 프로젝트 관리
- **기능:**
  - 새 프로젝트 만들기 버튼
  - 프로젝트 카드 목록
  - 프로젝트별 진행 상황 표시 (3/12)
  - 프로젝트 선택/편집/삭제
- **상태 표시:**
  - 진행 중 (녹색)
  - 완료 (회색)

#### 영역 ② 📊 진행 프로세스
- **목적:** 선택한 프로젝트의 개발 프로세스 단계별 확인
- **구조:**
  - Phase별 그룹화 (P1_사업계획 ~ 4_운영)
  - 3단계 계층 구조 (Major → Small → Tiny)
- **상태 아이콘:**
  - ✅ 완료 (녹색 체크)
  - 🔵 진행 중 (파란색 점)
  - ⚪ 대기 (회색 점)
  - 🔴 보류 (빨간색 점)
- **인터랙션:**
  - Task 클릭 → 중앙 워크스페이스에 상세 정보
  - Task 우클릭 → 상태 변경
  - Progress bar 표시

#### 영역 ③ 🔗 연계 서비스 바로가기
- **목적:** 자주 사용하는 기능에 빠르게 접근
- **항목:**
  - 🏠 대시보드
  - 📊 프로젝트 그리드
  - 💬 써니에게 묻기
  - 🪙 크레딧 충전
  - ⚙️ 설정

### 중앙 워크스페이스 (2개 영역)

#### 영역 ④ Workspace (상단 75%)
- **목적:** 실제 작업 공간
- **기능:**
  1. **Order Sheet 작성 영역**
     - 템플릿 자동 로드
     - 한영 병기 번역 미리보기
     - Download Order Sheet 버튼
  2. **AI 응답 표시 영역**
     - ChatGPT/Gemini/Perplexity 답변
  3. **Outbox 결과 표시 영역**
     - Claude Code 작업 결과물

#### 영역 ⑤ Project SAL Grid (하단 25%)
- **목적:** 전체 프로젝트 진행 상황 한눈에 파악
- **표시 정보:**
  - Stats Bar (완료/진행 중/대기 Task 수)
  - Area별 Task Cards
  - Task 상태별 색상 구분
- **뷰 모드:**
  - 2D Card View
  - 3D Block View
- **인터랙션:**
  - Task 카드 클릭 → 상세 정보
  - 전체화면 모드 (Fullscreen)

### 우측 사이드바 (6개 영역)

#### 영역 ⑥ 📚 학습용 콘텐츠 (Books)
- **목적:** 웹 개발 지식 학습
- **무료 제공** (회원가입만으로 열람 가능)
- **구조:**
  - 3단계 계층 구조 (Major → Medium → Small)
  - 카테고리별 아티클
- **내용:**
  - HTML/CSS 기초
  - JavaScript 심화
  - React/Next.js
  - Node.js/Express
  - Supabase/DB
  - Deployment

#### 영역 ⑦ 🙋 FAQ
- **목적:** 자주 묻는 질문 즉시 해결
- **무료 제공**
- **카테고리:**
  - 서비스 이용
  - 결제 문의
  - 기술 문제
  - 보안
- **인터랙션:**
  - 질문 클릭 → 답변 펼침

#### 영역 ⑧ 🔔 Claude Code 업데이트
- **목적:** Claude Code CLI 최신 소식
- **무료 제공**
- **내용:**
  - 업데이트 알림
  - 새 기능 소개
  - 버전 정보

#### 영역 ⑨ 🤖 AI묻기 (AI Q&A)
- **목적:** AI에게 질문하고 답변 받기
- **크레딧 충전 필요** (유료)
- **AI 제공:**
  - ChatGPT GPT-5
  - Gemini 2.5 Pro
  - Perplexity (크레딧 소진)
- **UI:**
  - AI 선택 버튼 (3개)
  - 질문 입력창
  - 답변 표시 영역
  - 크레딧 잔액 표시

#### 영역 ⑩ ☀️ Sunny묻기 (Support)
- **목적:** 인간 전문가(Sunny)에게 문의
- **무료 제공**
- **기능:**
  - 텍스트 질문
  - 파일 첨부 (이미지, 로그 등)
  - 답변 표시
- **응답 시간:** 24시간 이내

#### 영역 ⑪ 📢 공지사항
- **목적:** 서비스 업데이트 및 공지
- **무료 제공**
- **내용:**
  - 신규 기능 출시
  - 점검 안내
  - 이벤트 정보

---

## 2. User Flow #1: 회원가입 (Signup)

**Source:** `1_Signup/flow.md`

### 흐름 요약
1. 랜딩 페이지 → "회원가입" 버튼
2. 회원가입 폼 입력
   - 이메일 (필수, 고유)
   - 비밀번호 (필수, 8자+, 영문+숫자+특수문자)
   - 비밀번호 확인
   - 닉네임 (필수, 2-20자, 중복 검증)
   - 실명 (필수, 2-50자) - 설치비/환불/세금계산서용
3. 약관 동의
   - 서비스 이용약관 (필수)
   - 개인정보 처리방침 (필수)
   - 마케팅 수신 (선택)
4. 회원가입 버튼 클릭
5. 서버 검증 (이메일 중복, 닉네임 중복, 비밀번호 강도)
6. 계정 생성
   - Supabase Auth 계정
   - users 테이블 레코드 (user_id: 8자리 랜덤 영숫자)
   - 초기 상태: subscription_status='free', installation_fee_paid=false, credit_balance=0
7. 환영 팝업
   - 무료 기능 안내 (Books, FAQ, 사용 설명서)
   - 유료 기능 안내 (AI Q&A는 크레딧, 프로젝트 등록은 설치비)
8. Dashboard 진입

### API
- `POST /api/auth/signup`

### 성공 기준
- ✅ Books 무료 열람 가능
- ✅ 프로젝트 등록은 설치비(₩3,000,000) 필요
- ✅ AI Q&A는 크레딧 충전 필요

---

## 3. User Flow #2: 프로젝트 등록 (Project Registration)

**Source:** `2_Project_Registration/flow.md`

### 전제 조건
- **설치비 납부 필수** (₩3,000,000)
- 설치비 납부 후 평생 무제한 프로젝트 등록 가능
- 단, 동시 진행은 1개만 (완료 후 다음 프로젝트 시작)

### 흐름 요약
1. Dashboard → "새 프로젝트" 버튼
2. 설치비 납부 확인
   - 미납: 설치비 납부 안내 모달 → 결제 페이지
   - 완료: 프로젝트 등록 폼
3. 프로젝트 정보 입력
   - 프로젝트 이름 (필수)
   - 프로젝트 유형 선택 (웹사이트 개발/앱 개발/기타)
   - 간단한 설명 (선택)
4. PROJECT SAL Grid 자동 생성
   - 5 Phases (P1_사업계획 ~ 4_운영)
   - 각 Phase별 기본 Task 자동 생성
5. 프로젝트 카드 생성
   - 좌측 사이드바 영역 ①에 표시
   - 진행 상황 표시 (0/25)
6. Workspace에 프로젝트 로드
   - Order Sheet 작성 가능
   - SAL Grid 표시

### 특별 혜택 (설치비 납부 시)
- ✅ 프로젝트 평생 무제한 등록
- ✅ 플랫폼 이용료 3개월 무료
- ✅ 성공 시 50% 환불 (₩1,500,000)

### 문서
- `작성법_안내.md` - Order Sheet 작성 가이드
- `사용법_안내.md` - Dashboard 사용법
- `ui_specs.md` - UI 명세

---

## 4. User Flow #3: 구독 관리 (Subscription)

**Source:** `3_Subscription/flow.md`

### 가격 구조
- **무료 (Free):**
  - Books 무제한
  - FAQ 무제한
  - 사용 설명서
  - 서비스 소개

- **크레딧 충전 (Pay-per-use):**
  - AI Q&A (ChatGPT, Gemini, Perplexity)
  - 질문당 크레딧 소진

- **설치비 (One-time):**
  - ₩3,000,000 (1회 납부)
  - 프로젝트 평생 무제한 등록
  - 성공 시 50% 환불

### 흐름 (설치비 납부)
1. 설정 → "설치비 납부" 버튼
2. 결제 정보 확인
   - 금액: ₩3,000,000
   - 입금 계좌 표시
   - 입금자명 = 실명
3. 무통장 입금 또는 카드 결제
4. 입금 확인 (관리자 수동 확인)
5. `installation_fee_paid = true` 업데이트
6. 프로젝트 등록 활성화

---

## 5. User Flow #4: 크레딧 충전 (Credit Purchase)

**Source:** `4_Credit_Purchase/flow.md`

### 크레딧 사용처
- 🤖 AI Q&A (ChatGPT, Gemini, Perplexity)

### 충전 단위
- ₩10,000 = 10,000 크레딧
- ₩30,000 = 30,000 크레딧
- ₩50,000 = 50,000 크레딧
- ₩100,000 = 100,000 크레딧

### 흐름
1. 영역 ⑨ "AI묻기" → "크레딧 충전" 버튼
2. 충전 금액 선택
3. 결제 (토스페이먼츠)
4. 크레딧 즉시 충전
5. 잔액 표시 업데이트

### 크레딧 소진 로직
- ChatGPT: 100 크레딧/질문
- Gemini: 80 크레딧/질문
- Perplexity: 200 크레딧/질문 (실시간 검색)

---

## 6. User Flow #5: 프로젝트 개발 (Project Development)

**Source:** `5_Project_Development/flow.md`

### 전체 프로세스
1. **프로젝트 선택** (영역 ①)
2. **Phase/Task 선택** (영역 ②)
3. **Order Sheet 작성** (영역 ④)
   - 좌측 사이드바에서 카테고리 클릭 → 템플릿 자동 로드
   - 요구사항 작성 (한글)
   - 실시간 번역 미리보기 (한영 병기)
4. **Download Order Sheet**
   - JSON 파일로 Inbox에 저장
   - Order ID 자동 생성 (ORDER-{AREA}-{YYMMDD}-{SEQ})
5. **Claude Code 작업**
   - CLI가 Inbox 파일 감지
   - 자동 작업 시작
   - Outbox에 결과물 저장
6. **Outbox 확인** (영역 ④)
   - "Load from Outbox" 버튼
   - 실시간 알림 (5초 폴링)
   - 결과물 미리보기
7. **Task 완료 처리** (영역 ②)
   - Task 상태 업데이트 (진행 중 → 완료)
   - Progress bar 업데이트
   - SAL Grid 업데이트

### 실시간 기능
- **Outbox Watcher:** 5초마다 새 파일 확인
- **Order Status Tracking:** 3초마다 Order 상태 확인
- **Notification:** 새 결과물 알림 팝업

---

## 7. User Flow #6: AI Q&A (AI묻기)

**Source:** `6_AI_QA/` (inferred)

### 위치
- 영역 ⑨ 🤖 AI묻기

### 흐름
1. AI 선택 (ChatGPT / Gemini / Perplexity)
2. 질문 입력
3. 크레딧 잔액 확인
   - 부족 시 → 충전 안내
4. AI에게 질문 전송
5. 답변 표시 (영역 ④ Workspace)
6. 크레딧 자동 차감

### AI별 특징
- **ChatGPT GPT-5:** 코드 작성, 기술 문서 생성
- **Gemini 2.5 Pro:** 코드 리뷰, 아키텍처 설계
- **Perplexity:** 최신 기술 정보, 실시간 검색

---

## 8. User Flow #7: AI Integration (AI 연동)

**Source:** `7_AI_Integration/` (inferred)

### 개념
- SSAL Works ↔ AI Link Server ↔ AI APIs

### 아키텍처
```
[Dashboard] → [ai_server.js:4000] → [OpenAI/Gemini/Perplexity APIs]
    ↓
[결과 표시]
```

### 엔드포인트
- `POST /ask-chatgpt`
- `POST /ask-gemini`
- `POST /ask-perplexity`

---

## 9. User Flow #8: Support (Sunny묻기)

**Source:** `8_Support/` (inferred)

### 위치
- 영역 ⑩ ☀️ Sunny묻기

### 흐름
1. 질문 입력
2. 파일 첨부 (선택)
   - 이미지, 로그, 코드 파일 등
3. "문의하기" 버튼
4. 서버로 전송
5. Sunny 답변 (24시간 이내)
6. 답변 표시 (영역 ⑩)

### 무료 제공
- ✅ 제한 없는 문의
- ✅ 전문가 답변

---

## User Flow Integration Points for Mockup

### Critical Integration Points

1. **Header (상단바)**
   - 로그인/회원가입 버튼
   - 사용자 닉네임 표시
   - 알림 아이콘

2. **좌측 사이드바 영역 ①**
   - "새 프로젝트" 버튼 → Project Registration Flow
   - 프로젝트 카드 목록
   - 프로젝트 선택 인터랙션

3. **좌측 사이드바 영역 ②**
   - Phase별 Task 트리
   - Task 상태 아이콘 (✅🔵⚪🔴)
   - Task 클릭 → Workspace 연동
   - Progress bar

4. **좌측 사이드바 영역 ③**
   - 바로가기 링크들
   - 크레딧 충전 버튼

5. **중앙 Workspace 영역 ④**
   - Order Sheet 작성 영역
   - 템플릿 로드 버튼들
   - 번역 미리보기
   - Download Order Sheet 버튼
   - Load from Outbox 버튼
   - AI 응답 표시

6. **중앙 SAL Grid 영역 ⑤**
   - Stats Bar
   - Task Cards
   - 2D/3D 뷰 전환
   - Fullscreen 버튼

7. **우측 사이드바 영역 ⑥-⑪**
   - Books 3단계 트리
   - FAQ 아코디언
   - AI 선택 버튼 (3개)
   - AI 질문 입력창
   - 크레딧 잔액 표시
   - Sunny 문의 폼
   - 공지사항 목록

### Interactive Elements (247개)

**From previous analysis:**
- onclick handlers: Task 선택, 프로젝트 선택, 모달 열기/닫기
- ondblclick: VS Code 폴더 열기
- onchange: 파일 첨부
- oninput: 실시간 번역 (300ms debounce)
- Expansion/collapse: 3단계 트리 구조
- Real-time polling: Outbox (5s), Order status (3s)

---

## Design Patterns to Implement

### 1. Hierarchical Trees (좌측/우측 사이드바)
```javascript
.process-small-list { max-height: 0; transition: max-height 0.3s; }
.process-small-list.expanded { max-height: 600px; }
```

### 2. Status Indicators
- ✅ Completed: `color: var(--success)`
- 🔵 In Progress: `color: var(--warning)`
- ⚪ Pending: `color: var(--neutral)`
- 🔴 On Hold: `color: var(--danger)`

### 3. Real-time Notifications
```javascript
// Outbox Watcher
setInterval(async () => {
    const response = await fetch('/outbox/files');
    if (newFiles) showOutboxNotification();
}, 5000);
```

### 4. Bilingual Markdown
```markdown
<!-- 🇰🇷 한글 내용 -->
English content
```

### 5. Multi-AI Integration
```javascript
const aiEndpoints = {
    'chatgpt': '/ask-chatgpt',
    'gemini': '/ask-gemini',
    'perplexity': '/ask-perplexity'
};
```

---

## Summary

**Total User Flows:** 8+ flows
**Total Areas:** 11 areas (3 left + 2 center + 6 right)
**Interactive Elements:** 247+
**Key Features:**
- 무료 회원가입
- Books 무료 열람
- 설치비 기반 프로젝트 등록
- 크레딧 기반 AI Q&A
- 실시간 Outbox 모니터링
- Order Sheet 자동 번역
- 3단계 계층 트리 구조
- Multi-AI 통합

**Mockup Requirements:**
- All 11 areas must be functional
- All 247 interactive elements must work
- Real-time polling (Outbox/Order status)
- Translation system
- Hierarchical expansion/collapse
- Project/Task management UI
- AI integration UI
- Support system UI

---

**End of User Flow Summary**
