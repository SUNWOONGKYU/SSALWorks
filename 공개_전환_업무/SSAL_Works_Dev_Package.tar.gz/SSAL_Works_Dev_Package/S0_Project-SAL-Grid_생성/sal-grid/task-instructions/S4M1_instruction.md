# Task Instruction - S4M1

---

## 📌 필수 참조 규칙 파일 (2025-12-19)

> **⚠️ 작업 전 반드시 아래 규칙 파일을 확인하세요!**

| 규칙 파일 | 내용 | 참조 시점 |
|----------|------|----------|
| `.claude/rules/01_file-naming.md` | 파일 명명 규칙 | 파일 생성 시 |
| `.claude/rules/02_save-location.md` | 저장 위치 규칙 | 파일 저장 시 |
| `.claude/rules/03_area-stage.md` | Area/Stage 매핑 | 폴더 선택 시 |
| `.claude/rules/05_execution-process.md` | 6단계 실행 프로세스 | 작업 전체 |



## Task ID
S4M1

## Task Name
관리자 가이드

## Task Goal
Admin Dashboard 사용법 문서 작성 - 관리자 기능 사용 가이드

## Prerequisites (Dependencies)
- S4F1 (관리자 대시보드 강화) 완료

## Specific Instructions

### 1. 문서 구조
- 위치: `S4_개발-3차/Documentation/ADMIN_GUIDE.md`
- 형식: Markdown

### 2. 필수 포함 내용

#### 2.1 관리자 대시보드 접속
```markdown
## 관리자 대시보드 접속

### 접속 URL
- 프로덕션: https://ssalworks.ai.kr/admin
- 개발: http://localhost:3000/admin

### 접속 권한
- 관리자 계정으로 로그인 필요
- users 테이블 role='admin' 필수
```

#### 2.2 주요 기능 설명

```markdown
## 대시보드 주요 기능

### 1. 통계 대시보드
- 일/주/월별 가입자 수
- 구독 현황 (활성/해지/만료)
- AI 사용량 통계
- 매출 현황

### 2. 사용자 관리
- 사용자 목록 조회 및 검색
- 사용자 상세 정보 확인
- 구독 상태 수정
- 계정 일시정지/해제

### 3. 구독 관리
- 구독 신청 승인/거부
- 구독 기간 연장
- 수동 구독 생성
- 환불 처리

### 4. 결제 관리
- 결제 내역 조회
- 환불 처리
- 설치비 입금 확인
- 결제 실패 재시도

### 5. 콘텐츠 관리
- 학습 콘텐츠 목록 관리
- FAQ 관리
- 공지사항 관리

### 6. 시스템 설정
- AI 가격 설정
- 크레딧 패키지 설정
- 알림 설정
```

#### 2.3 사용자 관리 상세
```markdown
## 사용자 관리

### 사용자 검색
1. 검색창에 이메일 또는 이름 입력
2. 필터 옵션 선택 (구독 상태, 가입일 등)
3. 검색 버튼 클릭

### 사용자 상세 보기
- 기본 정보 (이메일, 이름, 가입일)
- 구독 정보 (플랜, 시작일, 만료일)
- 결제 내역
- AI 사용 이력
- 로그인 기록

### 사용자 작업
- **구독 상태 변경**: 드롭다운에서 상태 선택 후 저장
- **계정 일시정지**: 사유 입력 후 확인
- **관리자 권한 부여**: 역할 변경 (주의 필요)
```

#### 2.4 구독 승인 프로세스
```markdown
## 구독 승인 프로세스

### 신규 구독 신청 확인
1. 대시보드 > 구독 관리 > 대기 중 탭
2. 신청 내역 확인 (사용자 정보, 선택 플랜)
3. 결제 완료 여부 확인

### 승인 절차
1. 신청 건 클릭 > 상세 정보 확인
2. 결제 정보 일치 확인
3. '승인' 버튼 클릭
4. 자동으로 사용자에게 알림 발송

### 거부 절차
1. '거부' 버튼 클릭
2. 거부 사유 입력 (필수)
3. 확인 클릭
4. 사용자에게 거부 사유 알림 발송
```

#### 2.5 설치비 입금 확인
```markdown
## 설치비 입금 확인

### 입금 확인 절차
1. 대시보드 > 결제 관리 > 설치비 탭
2. 대기 중인 입금 신청 확인
3. 은행 계좌 입금 내역과 대조
   - 입금자명 일치 여부
   - 입금액 일치 여부 (990,000원)
4. '입금 확인' 버튼 클릭

### 주의사항
- 입금자명이 다른 경우 사용자에게 확인
- 금액이 다른 경우 차액 처리 방안 결정
- 입금 확인 후 자동으로 프로젝트 활성화
```

### 3. 트러블슈팅 가이드
```markdown
## 자주 발생하는 문제

### 결제 실패 처리
1. 결제 내역에서 실패 건 확인
2. 실패 사유 확인 (잔액 부족, 카드 오류 등)
3. 사용자에게 연락하여 재결제 안내
4. 필요시 수동 구독 처리

### 구독 상태 불일치
1. DB 직접 조회 (`subscription_status`)
2. 결제 내역과 대조
3. 필요시 상태 수동 수정

### API 에러 대응
1. Sentry에서 에러 로그 확인
2. 에러 패턴 분석
3. 필요시 개발팀에 전달
```

## Expected Output Files
- `S4_개발-3차/Documentation/ADMIN_GUIDE.md`

## Completion Criteria
- [ ] 대시보드 접속 방법 설명
- [ ] 통계 대시보드 사용법
- [ ] 사용자 관리 기능 설명
- [ ] 구독 승인/거부 프로세스 설명
- [ ] 결제 관리 방법 설명
- [ ] 설치비 입금 확인 절차 설명
- [ ] 트러블슈팅 가이드 포함

## Tech Stack
- Markdown

## Task Agent
`documentation-specialist`

## Verification Agent
`code-reviewer`

## Tools
- 없음 (문서 작업)

## Execution Type
AI-Only

## Remarks
- 실제 대시보드 UI 스크린샷 추가 권장
- 비기술직도 이해할 수 있는 수준으로 작성
- 정기적으로 업데이트 필요

---

## ⚠️ 작업 결과물 저장 2대 규칙

> **이 규칙은 반드시 준수하세요!**

### 제1 규칙: Stage + Area 폴더에 저장
- Task ID의 Stage와 Area에 해당하는 폴더에 저장
- 예: S1S1 → `S1_개발_준비/Security/`
- 예: S2F1 → `S2_개발-1차/Frontend/`

### 제2 규칙: Production 코드는 이중 저장
- Frontend, Database, Backend_APIs 코드는 Stage 폴더 + Production 폴더 둘 다 저장
- 문서(Documentation, Security, Testing, DevOps)는 Stage 폴더에만 저장

**Area 폴더 매핑:** M→Documentation, F→Frontend, BI→Backend_Infra, BA→Backend_APIs, D→Database, S→Security, T→Testing, O→DevOps, E→External, C→Content
