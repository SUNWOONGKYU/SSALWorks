# S5U2: 반응형 디자인 최적화

## Task 개요
- **Task ID**: S5U2
- **Task Name**: 반응형 디자인 최적화
- **Area**: U (Design)
- **Stage**: S5 (개발 마무리)
- **Dependencies**: S5U1 (디자인 QA 및 일관성 점검)
- **Task Agent**: `frontend-developer`
- **Verification Agent**: `code-reviewer`

## 목적
SSALWorks 플랫폼이 PC 중심이지만, 모바일 기기에서도 콘텐츠를 **읽을 수 있도록** 반응형 디자인을 적용한다.

> **중요**: 모바일에서 "작업"을 하는 것이 아니라 "확인/읽기"만 가능하면 됨

## 작업 범위

### 1. 모바일 뷰포트 대응 (필수)
- 768px 이하에서 콘텐츠 가독성 확보
- 텍스트 크기 최소 14px 유지
- 가로 스크롤 방지 (overflow-x: hidden)

### 2. 레이아웃 조정 (필수)
- 사이드바: 모바일에서 숨기거나 토글 메뉴로 변환
- 메인 콘텐츠: 100% 너비 사용
- 그리드: 1컬럼 레이아웃으로 변환

### 3. 터치 친화성 (권장)
- 터치 타겟 최소 44px
- 버튼/링크 간격 확보
- 스와이프 제스처 충돌 방지

### 4. 모바일 제외 기능 안내
- PC 전용 기능에 대한 안내 메시지 표시
- "데스크톱에서 이용해 주세요" 배너 (모바일 접속 시)

## 대상 페이지
1. index.html (메인 대시보드)
2. viewer.html (Grid Viewer)
3. pages/auth/*.html (인증 페이지)
4. pages/mypage/*.html (마이페이지)
5. admin-dashboard.html (관리자)

## CSS 미디어 쿼리 예시

```css
/* 태블릿 (768px ~ 1024px) */
@media (max-width: 1024px) {
    .sidebar {
        width: 200px;
    }
    .main-content {
        margin-left: 200px;
    }
}

/* 모바일 (768px 이하) */
@media (max-width: 768px) {
    .sidebar {
        display: none; /* 또는 토글 메뉴로 변환 */
    }
    .main-content {
        margin-left: 0;
        width: 100%;
        padding: 10px;
    }
    .grid-container {
        grid-template-columns: 1fr;
    }
    /* 모바일 전용 배너 */
    .mobile-notice {
        display: block;
        background: #FEF3C7;
        padding: 10px;
        text-align: center;
    }
}

/* 데스크톱 (769px 이상) */
@media (min-width: 769px) {
    .mobile-notice {
        display: none;
    }
}
```

## 사용 도구
- browser-mcp: 브라우저 렌더링 확인
- playwright-mcp: 반응형 스크린샷
- Chrome DevTools: 반응형 디자인 모드

## 테스트 해상도
- 모바일: 375px, 425px
- 태블릿: 768px
- 데스크톱: 1024px, 1280px, 1920px

## 결과물
- `S5_개발_마무리/Frontend/responsive.css` 또는 기존 CSS에 미디어 쿼리 추가
- `Production/Frontend/` 동기화
- 반응형 테스트 스크린샷 (선택)

## 완료 기준
- [ ] 모바일(375px)에서 가로 스크롤 없음
- [ ] 모든 텍스트 읽기 가능 (최소 14px)
- [ ] 주요 콘텐츠 접근 가능
- [ ] PC 전용 기능 안내 표시
- [ ] 레이아웃 깨짐 없음

## 작업 우선순위
1. 가독성 확보 (필수)
2. 레이아웃 조정 (필수)
3. 터치 친화성 (권장)
4. PC 전용 안내 배너 (권장)

---

## 📌 필수 참조 규칙 파일

| 규칙 파일 | 내용 | 참조 시점 |
|----------|------|----------|
| `.claude/rules/01_file-naming.md` | 파일 명명 규칙 | 파일 생성 시 |
| `.claude/rules/02_save-location.md` | 저장 위치 규칙 | 파일 저장 시 |
| `.claude/rules/03_area-stage.md` | Area/Stage 매핑 | 폴더 선택 시 |
| `.claude/rules/05_execution-process.md` | 6단계 실행 프로세스 | 작업 전체 |

### 📂 결과물 저장 규칙

> **이 규칙은 반드시 준수하세요!**

### 제1 규칙: Stage + Area 폴더에 저장
- Task ID의 Stage와 Area에 해당하는 폴더에 저장
- 예: S5U2 → `S5_개발_마무리/Frontend/` (CSS 파일)

### 제2 규칙: Production 코드는 이중 저장
- Frontend 코드는 Stage 폴더 + Production 폴더 둘 다 저장

**Area 폴더 매핑:** M→Documentation, U→Design(보통 Frontend에 CSS 저장), F→Frontend, BI→Backend_Infra, BA→Backend_APIs, D→Database, S→Security, T→Testing, O→DevOps, E→External, C→Content
